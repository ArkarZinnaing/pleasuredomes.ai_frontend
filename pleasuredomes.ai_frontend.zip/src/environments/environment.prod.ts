


export const environment = {
  production: false,
  apiServer: 'http://150.95.26.123:3010/',
  defaultLoadingImage: 'assets/images/image-loading.gif',
  errorImage: 'assets/images/no-photo.jpg',
};


