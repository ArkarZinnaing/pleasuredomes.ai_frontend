export class AiPerson {
    id!: string
    name!: string
    image!: string
    dob!: string
    gender!: string
    location!: string
    description!: string
}